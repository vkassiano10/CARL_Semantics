package suitceyes.Connectors;

public class SuitceyesAPIConnector {
}
